import 'package:flutter/material.dart';
import 'dart:async';

class NotificationIcon extends StatefulWidget {
  @override
  _NotificationIconState createState() => _NotificationIconState();
}

class _NotificationIconState extends State<NotificationIcon> {
  List<String> _notifications = [
    "Rider is outside!",
    "Order a rider now!",
    "Driver approaching in 2 min.",
  ];
  int _index = 0;
  bool _showPopup = false;

  @override
  void initState() {
    super.initState();
    Timer.periodic(Duration(seconds: 8), (timer) {
      if (mounted) {
        setState(() => _index = (_index + 1) % _notifications.length);
      }
    });
  }

  void _togglePopup() => setState(() => _showPopup = !_showPopup);

  @override
  Widget build(BuildContext context) {
    return Stack(
      children: [
        IconButton(icon: Icon(Icons.notifications), onPressed: _togglePopup),
        if (_showPopup)
          Positioned(
            top: 50,
            right: 10,
            child: Material(
              color: Colors.white,
              child: Container(
                padding: EdgeInsets.all(10),
                width: 200,
                child: Column(
                  children: [
                    Text(_notifications[_index], style: TextStyle(color: Colors.black)),
                    TextButton(onPressed: _togglePopup, child: Text("Close"))
                  ],
                ),
              ),
            ),
          )
      ],
    );
  }
}