import 'package:flutter/material.dart';

class ChatWidget extends StatefulWidget {
  @override
  _ChatWidgetState createState() => _ChatWidgetState();
}

class _ChatWidgetState extends State<ChatWidget> {
  bool _expanded = false;

  @override
  Widget build(BuildContext context) {
    return ExpansionPanelList(
      expansionCallback: (int index, bool isExpanded) {
        setState(() => _expanded = !_expanded);
      },
      children: [
        ExpansionPanel(
          headerBuilder: (context, isExpanded) {
            return ListTile(title: Text("Chat with Driver"));
          },
          body: Column(
            children: [
              ListTile(title: Text("Driver: John Doe")),
              ListTile(title: Text("Vehicle: Toyota Corolla")),
              ListTile(title: Text("ETA: 5 mins")),
              Padding(
                padding: EdgeInsets.all(8.0),
                child: TextField(decoration: InputDecoration(hintText: "Type message...")),
              ),
            ],
          ),
          isExpanded: _expanded,
        ),
      ],
    );
  }
}