import 'package:flutter/material.dart';
import 'splash_screen.dart';

void main() {
  runApp(RawRidersApp());
}

class RawRidersApp extends StatelessWidget {
  @override
  Widget build(BuildContext context) {
    return MaterialApp(
      title: 'RawRiders Taxi Inc.',
      theme: ThemeData.dark(),
      debugShowCheckedModeBanner: false,
      home: SplashScreen(),
    );
  }
}