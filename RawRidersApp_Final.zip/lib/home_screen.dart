import 'package:flutter/material.dart';
import 'map_screen.dart';
import 'chat_widget.dart';
import 'notifications.dart';
import 'utils/city_autocomplete.dart';

class HomeScreen extends StatefulWidget {
  @override
  _HomeScreenState createState() => _HomeScreenState();
}

class _HomeScreenState extends State<HomeScreen> {
  final TextEditingController _destinationController = TextEditingController();
  String _selectedCity = '';

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('RawRiders Taxi Inc.'),
        actions: [
          NotificationIcon(),
        ],
      ),
      body: Padding(
        padding: EdgeInsets.all(16.0),
        child: Column(
          children: [
            Autocomplete<String>(
              optionsBuilder: (textEditingValue) {
                return CityAutocomplete.getSuggestions(textEditingValue.text);
              },
              onSelected: (selection) {
                setState(() {
                  _selectedCity = selection;
                });
              },
              fieldViewBuilder: (context, controller, focusNode, onEditingComplete) {
                _destinationController.text = controller.text;
                return TextField(
                  controller: controller,
                  focusNode: focusNode,
                  decoration: InputDecoration(
                    labelText: 'Enter Destination (e.g., LSK)',
                    suffixIcon: Icon(Icons.search),
                  ),
                );
              },
            ),
            SizedBox(height: 20),
            ChatWidget(),
          ],
        ),
      ),
      floatingActionButton: FloatingActionButton(
        onPressed: () => Navigator.push(context, MaterialPageRoute(builder: (_) => MapScreen())),
        child: Icon(Icons.local_taxi),
        backgroundColor: Colors.amber,
        tooltip: 'Start New Ride',
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.startFloat,
    );
  }
}