class CityAutocomplete {
  static List<String> cities = [
    'Lusaka',
    'Kitwe',
    'Ndola',
    'Livingstone',
    'Choma',
    'Chipata',
    'Kabwe',
    'Mansa',
    'Kasama',
    'Solwezi',
  ];

  static List<String> getSuggestions(String input) {
    input = input.toLowerCase();
    return cities.where((city) => city.toLowerCase().contains(input)).toList();
  }
}