import 'package:flutter/material.dart';
import 'dart:async';

class MapScreen extends StatefulWidget {
  @override
  _MapScreenState createState() => _MapScreenState();
}

class _MapScreenState extends State<MapScreen> with SingleTickerProviderStateMixin {
  late AnimationController _controller;
  late Animation<double> _animation;
  double _position = 0;

  @override
  void initState() {
    super.initState();
    _controller = AnimationController(
      duration: const Duration(seconds: 6),
      vsync: this,
    )..repeat(reverse: true);
    _animation = Tween<double>(begin: 0, end: 300).animate(_controller)
      ..addListener(() {
        setState(() {
          _position = _animation.value;
        });
      });
  }

  @override
  void dispose() {
    _controller.dispose();
    super.dispose();
  }

  @override
  Widget build(BuildContext context) {
    return Scaffold(
      appBar: AppBar(
        title: Text('Ride Map'),
        actions: [
          IconButton(
            icon: Icon(Icons.arrow_back),
            onPressed: () => Navigator.pop(context),
          )
        ],
      ),
      body: Stack(
        children: [
          CustomPaint(
            size: Size(double.infinity, double.infinity),
            painter: RoadPainter(),
          ),
          Positioned(
            left: _position + 20,
            top: 250,
            child: Icon(Icons.directions_car, size: 50, color: Colors.amber),
          ),
        ],
      ),
    );
  }
}

class RoadPainter extends CustomPainter {
  @override
  void paint(Canvas canvas, Size size) {
    final paint = Paint()
      ..color = Colors.grey[800]!
      ..strokeWidth = 10
      ..style = PaintingStyle.stroke;

    final dashedPaint = Paint()
      ..color = Colors.white
      ..strokeWidth = 2;

    final path = Path();
    path.moveTo(20, size.height / 2);
    path.lineTo(size.width - 20, size.height / 2);
    canvas.drawPath(path, paint);

    for (double i = 20; i < size.width - 20; i += 40) {
      canvas.drawLine(Offset(i, size.height / 2), Offset(i + 20, size.height / 2), dashedPaint);
    }
  }

  @override
  bool shouldRepaint(CustomPainter oldDelegate) => false;
}